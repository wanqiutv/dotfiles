**System and Shadowsocksx-NG version:**

- macOS 10.??.?? (16E????)
- Shadowsocksx-NG 1.?

**Expected behavior:**



**Actual behavior:**

(N/A for feature requests)

**Steps to reproduce:**

(N/A for feature requests)

**How often does this happen?**

(N/A for feature requests)

**ss-local.log**

Please upload the ss-local.log file here the file is in `~/Library/Logs`
1) Open 'Advanced Settings -> enable Verbose Mode'
2) Continue run `Shadowsocksx-NG` for 5 minutes
3) Upload the `~/Library/Logs/ss-local.log` here (with or without compress)

**Application log**

Open the `Console.app` and search `Shadowsocksx-NG`
Copy paste the log here

**Crash Log**

If the app crashes and pop up a crash log, please copy and paste here

