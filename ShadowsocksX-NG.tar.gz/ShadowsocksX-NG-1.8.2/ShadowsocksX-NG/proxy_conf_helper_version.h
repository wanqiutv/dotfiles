//
//  proxy_conf_helper_version.h
//  ShadowsocksX-NG
//
//  Created by 邱宇舟 on 16/6/10.
//  Copyright © 2016年 qiuyuzhou. All rights reserved.
//

#ifndef proxy_conf_helper_version_h
#define proxy_conf_helper_version_h

#define kProxyConfHelperVersion @"1.7.0"

#endif /* proxy_conf_helper_version_h */
