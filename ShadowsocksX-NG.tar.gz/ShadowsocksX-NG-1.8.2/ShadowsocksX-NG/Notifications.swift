//
//  Notifications.swift
//  ShadowsocksX-NG
//
//  Created by 邱宇舟 on 16/6/7.
//  Copyright © 2016年 qiuyuzhou. All rights reserved.
//

import Foundation

let NOTIFY_SERVER_PROFILES_CHANGED = Notification.Name(rawValue: "NOTIFY_SERVER_PROFILES_CHANGED")

let NOTIFY_CONF_CHANGED = Notification.Name(rawValue: "NOTIFY_CONF_CHANGED")

let NOTIFY_TOGGLE_RUNNING_SHORTCUT = Notification.Name(rawValue: "NOTIFY_TOGGLE_RUNNING_SHORTCUT")
let NOTIFY_SWITCH_PROXY_MODE_SHORTCUT = Notification.Name(rawValue: "NOTIFY_SWITCH_PROXY_MODE_SHORTCUT")

let NOTIFY_FOUND_SS_URL = Notification.Name(rawValue: "NOTIFY_FOUND_SS_URL")
